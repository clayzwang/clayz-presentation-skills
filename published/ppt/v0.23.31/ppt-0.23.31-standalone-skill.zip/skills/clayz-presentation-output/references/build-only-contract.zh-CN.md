# 纯制作合同

## v0.17.2 current contract

New runs follow [Story and visual handoff](../../../packages/contracts/story-visual-handoff.md). Logic owns research findings; Copy owns content structure, pagination, wording and content tags; Art Direction locks full-deck images and visual specifications. The fields below describe the legacy page projection consumed by existing validators/renderers. Package 3.2 uses the current research/content contract; the older field examples below are historical and must not impose retired Logic rules on new work. Legacy coordinate-free restrictions apply to reusable patterns, not the task visual specification.

## Legacy / compatibility field reference

## 核心原则

Output把计划变成对象，不把对象重新解释成计划。批准计划是当前执行基准；任何未经实质基准决定、仅以“为了更好看”为由更改构图、媒介、面积、密度、动线、系列持久元素、母题、语义留白或持续导航的行为都属于越权。若原生实现暴露出上游问题，可以提出挑战并交 Supervisor 记录、取得必要的用户决定，但不得静默改变。质量缺陷可以带证据交给 Independent Auditor，不单独触发再次审批或拒绝交付。

## 对象制作顺序

1. 按中央配置加载生成主题或用户指定母版，并清除允许删除的样例对象；
2. 若配置使用母版，核验并保留其继承对象、动态页码和标题区；不得在页面层重复建立；
3. 创建背景分区与连接器；
4. 创建原生表格／图表／图片或关系主对象；
5. 创建节点、文本与注释；
6. 设置copy_id、render_target_id和对象层级；
7. 渲染、检查、返修。

同一 `series_id` 在步骤3前先建立共享制作基准：为持久元素生成稳定对象名、坐标、尺寸、样式和层级表。后续页复制这些基准，只执行 `progressive_change`；系列退出页按批准计划显式打破，不沿用旧壳。

## 技术偏差日志

```json
{
  "contract_version": "1.0",
  "package_id": "example-deck",
  "art_direction_plan_version": "1.3",
  "deviations": [
    {
      "deviation_id": "DEV-S10-01",
      "slide_id": "S10",
      "planned": "隐藏分类轴标签",
      "actual": "保留原生图表并用背景色遮罩冗余标签",
      "reason": "兼容引擎忽略隐藏属性",
      "changes_art_direction": false,
      "approved_by": "output-technical-contract",
      "backflow_status": "not-required"
    }
  ],
  "unresolved": []
}
```

允许偏差不改变观众第一视觉和语义。`unresolved` 非空时不得交付。

## 兼容性

原生图表、表格和母版字段优先。兼容性修补必须局部、可追溯、不得遮挡数据或改变比较关系。中央配置所列目标应用之间的渲染差异必须以最终实际渲染复核，不以对象属性推定通过。

若导出器丢失母版动态 `slidenum`、标题占位符或版式分隔线，停止该导出路径并改用能保留继承关系的受支持路径；不得用静态数字、页面横线或同位置叠加物冒充修复。任何母版兼容处理完成后，必须重新运行继承Chrome唯一性校验。

首页和尾页不得只依赖目标应用无法稳定呈现的版式层对象。只有兼容性探针证明需要时，才按中央配置增加可编辑的页内兜底；兜底不得与母版形成第二套视觉或重复对象。

最终兼容验收按证据强度排序：目标应用实际打开证据 ＞ 目标应用渲染 ＞ 制作端渲染 ＞ OOXML静态检查。缺少更强证据时执行通用兼容检查，并把证据缺口写入交付说明；本地单一渲染器通过不能代表全部配置目标。

## 交付体积

交付体积属于Output技术实现，不回流Art Direction改变主媒介。用户未提前指定时使用轻量传播档：图片先按最终显示框预处理，再插入PPTX；相同媒体只嵌入一次；清理未使用媒体、隐藏附件和意外字体。压缩导致局部可见损伤时只提高该资产质量，并记录技术偏差，不得擅自删除计划图片、改变面积或将整页栅格化。

最终写盘后生成 `ppt-size-audit.json`。超出总体软预算但没有单项低效时，可以保留并在QA中写具体必要性；存在重复、未使用、超分辨率或意外嵌入内容时必须返修，不能用总体例外掩盖。

